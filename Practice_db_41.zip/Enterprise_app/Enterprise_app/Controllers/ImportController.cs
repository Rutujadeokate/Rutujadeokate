﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Threading.Tasks;

namespace Enterprise_app.Controllers
{
    [ApiController]
    [Route("api/import")]
    public class ImportController : ControllerBase
    {
       
        private static readonly ConcurrentDictionary<string, string> JobStatus = new();
        private static readonly ConcurrentDictionary<string, string[]> JobRecords = new();

        
        [HttpPost("upload")]
        [Consumes("multipart/form-data")] 
        public async Task<IActionResult> UploadCsv([FromForm] IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest(new { error = "No file uploaded or file is empty." });

            var extension = Path.GetExtension(file.FileName);
            if (!string.Equals(extension, ".csv", StringComparison.OrdinalIgnoreCase))
                return BadRequest(new { error = "Only .csv files are allowed." });

            var jobId = Guid.NewGuid().ToString();
            JobStatus[jobId] = "Processing";

            var uploadPath = Path.Combine(Path.GetTempPath(), $"{jobId}{extension}");
            using (var stream = new FileStream(uploadPath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

           
            _ = Task.Run(async () =>
            {
                await Task.Delay(2000); 
                var lines = await System.IO.File.ReadAllLinesAsync(uploadPath);
                JobRecords[jobId] = lines;
                JobStatus[jobId] = "Completed";
            });

            return Ok(new { jobId });
        }

        
        [HttpGet("status/{jobId}")]
        public IActionResult GetStatus(string jobId)
        {
            if (!JobStatus.TryGetValue(jobId, out var status))
                return NotFound(new { error = "Job not found" });

            return Ok(new { jobId, status });
        }

       
        [HttpGet("records/{jobId}")]
        public IActionResult GetRecords(string jobId)
        {
            if (!JobRecords.TryGetValue(jobId, out var records))
                return NotFound(new { error = "Records not found or job not completed" });

            return Ok(new { jobId, records });
        }
    }
}