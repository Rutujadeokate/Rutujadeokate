﻿namespace Enterprise_app.Models
{
    public class ImportJob
    {
        public string JobId { get; set; }
        public JobStatus Status { get; set; }
        public int TotalRecords { get; set; }
        public int SuccessCount { get; set; }
        public int ErrorCount { get; set; }
        public List<ImportRecord> Records { get; set; } = new();
    }
}