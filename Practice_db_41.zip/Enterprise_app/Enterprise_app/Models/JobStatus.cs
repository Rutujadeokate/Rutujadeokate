﻿namespace Enterprise_app.Models
{
    public enum JobStatus
    {
        Pending,
        Processing,
        Completed,
        Failed
    }
}