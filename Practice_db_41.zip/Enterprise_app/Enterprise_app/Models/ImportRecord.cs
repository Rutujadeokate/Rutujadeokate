﻿namespace Enterprise_app.Models
{
    public class ImportRecord
    {
        public int RowNumber { get; set; }
        public string Data { get; set; }
        public string Status { get; set; } // "Success" or "Error"
        public string ErrorMessage { get; set; }
    }
}