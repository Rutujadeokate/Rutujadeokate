﻿using Enterprise_app.Models;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Enterprise_app.Services
{
    public class ImportJobService
    {
        private readonly ConcurrentDictionary<string, ImportJob> _jobs = new();

        public string CreateJob()
        {
            var jobId = Guid.NewGuid().ToString();
            _jobs[jobId] = new ImportJob
            {
                JobId = jobId,
                Status = JobStatus.Pending
            };
            return jobId;
        }

        public ImportJob GetJob(string jobId)
        {
            _jobs.TryGetValue(jobId, out var job);
            return job;
        }

        public async Task ProcessCsvAsync(string jobId, string filePath)
        {
            if (!_jobs.ContainsKey(jobId)) return;

            var job = _jobs[jobId];
            job.Status = JobStatus.Processing;

            try
            {
                var lines = await File.ReadAllLinesAsync(filePath);
                job.TotalRecords = lines.Length;

                int rowNumber = 1;
                foreach (var line in lines)
                {
                    // Simulate processing
                    if (string.IsNullOrWhiteSpace(line))
                    {
                        job.Records.Add(new ImportRecord
                        {
                            RowNumber = rowNumber,
                            Data = line,
                            Status = "Error",
                            ErrorMessage = "Empty row"
                        });
                        job.ErrorCount++;
                    }
                    else
                    {
                        job.Records.Add(new ImportRecord
                        {
                            RowNumber = rowNumber,
                            Data = line,
                            Status = "Success"
                        });
                        job.SuccessCount++;
                    }
                    rowNumber++;
                }

                job.Status = JobStatus.Completed;
            }
            catch (Exception ex)
            {
                job.Status = JobStatus.Failed;
                job.ErrorCount = job.TotalRecords;
                job.Records.Add(new ImportRecord
                {
                    RowNumber = 0,
                    Data = "",
                    Status = "Error",
                    ErrorMessage = ex.Message
                });
            }
        }
    }
}